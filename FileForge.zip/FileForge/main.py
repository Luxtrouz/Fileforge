import os
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import pandas as pd
import hashlib
import shutil
import re
import logging
import sys
import csv
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Optional
from dataclasses import dataclass
from PIL import Image, ImageTk
import fitz  # PyMuPDF
import io
import threading
import queue
from concurrent.futures import ThreadPoolExecutor
import gc
from functools import lru_cache
import time

# Logging setup
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[logging.StreamHandler()]
)
logger = logging.getLogger(__name__)

@dataclass
class RenameOperation:
    """Data class for tracking file rename operations"""
    original_index: int
    original_filename: str
    new_filename: str
    account_folder: str
    timestamp: datetime
    source_path: str
    destination_path: str
    account_display: str
    document_type: str

class PDFIndexerError(Exception):
    """Custom exception for PDF indexer operations"""
    pass

def natural_key(s: str) -> List:
    """Natural sorting key function for alphanumeric strings"""
    return [int(text) if text.isdigit() else text.lower() 
            for text in re.split(r'(\d+)', s)]

class ImageCache:
    """LRU cache for rendered PDF pages with memory management"""
    
    def __init__(self, max_size=10, max_memory_mb=100):
        self.max_size = max_size
        self.max_memory_bytes = max_memory_mb * 1024 * 1024
        self.cache = {}
        self.access_order = []
        self.memory_usage = 0
        
    def _estimate_image_size(self, image):
        """Estimate PIL image memory usage"""
        if hasattr(image, 'size'):
            width, height = image.size
            return width * height * 4  # Estimate 4 bytes per pixel (RGBA)
        return 0
        
    def _cleanup_oldest(self):
        """Remove oldest entries to free memory"""
        while ((len(self.cache) >= self.max_size or 
                self.memory_usage > self.max_memory_bytes) and 
               self.access_order):
            oldest_key = self.access_order.pop(0)
            if oldest_key in self.cache:
                image, size = self.cache.pop(oldest_key)
                self.memory_usage -= size
                del image  # Help garbage collection
                
    def get(self, key):
        """Get cached image"""
        if key in self.cache:
            # Move to end (most recently used)
            self.access_order.remove(key)
            self.access_order.append(key)
            return self.cache[key][0]
        return None
        
    def put(self, key, image):
        """Cache rendered image"""
        size = self._estimate_image_size(image)
        
        # Don't cache if image is too large
        if size > self.max_memory_bytes // 2:
            return
            
        self._cleanup_oldest()
        
        self.cache[key] = (image, size)
        self.memory_usage += size
        
        if key in self.access_order:
            self.access_order.remove(key)
        self.access_order.append(key)
        
    def clear(self):
        """Clear all cached images"""
        self.cache.clear()
        self.access_order.clear()
        self.memory_usage = 0
        gc.collect()

class TogglePDFViewer:
    """PDF viewer with toggle between single page and continuous view"""
    
    def __init__(self, parent, width=400, height=600):
        self.parent = parent
        self.width = width
        self.height = height
        self.pdf_document = None
        self.current_page = 0
        self.total_pages = 0
        self.zoom_level = 1.0
        self.min_zoom = 0.5
        self.max_zoom = 3.0
        self.page_gap = 20
        self.max_continuous_pages = 10  # Limit for performance
        
        # Performance optimizations
        self.image_cache = ImageCache(max_size=12, max_memory_mb=100)
        self.render_executor = ThreadPoolExecutor(max_workers=2, thread_name_prefix="pdf_render")
        self.current_render_future = None
        self.rendered_pages = {}
        self.page_positions = {}
        self.page_heights = {}
        
        # View mode
        self.is_continuous_mode = False
        
        self.setup_viewer()
        
    def setup_viewer(self):
        """Create the PDF viewer UI with themed toggle button"""
        self.main_frame = ttk.Frame(self.parent)
        self.main_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Toolbar
        toolbar_frame = ttk.Frame(self.main_frame)
        toolbar_frame.pack(fill=tk.X, pady=(0, 5))
        
        # Left side - navigation buttons (shown/hidden based on mode)
        self.nav_frame = ttk.Frame(toolbar_frame)
        self.nav_frame.pack(side=tk.LEFT)
        
        self.prev_btn = ttk.Button(self.nav_frame, text="◀", command=self.prev_page, width=3)
        self.prev_btn.pack(side=tk.LEFT, padx=2)
        
        self.next_btn = ttk.Button(self.nav_frame, text="▶", command=self.next_page, width=3)
        self.next_btn.pack(side=tk.LEFT, padx=2)
        
        # Page label
        self.page_label = ttk.Label(toolbar_frame, text="0 / 0")
        self.page_label.pack(side=tk.LEFT, padx=10)
        
        # Toggle button for continuous mode
        self.toggle_btn = ttk.Button(
            toolbar_frame, 
            text="Show All", 
            command=self.toggle_view_mode,
            width=10
        )
        self.toggle_btn.pack(side=tk.LEFT, padx=15)
        
        # Right side - zoom controls
        ttk.Button(toolbar_frame, text="−", command=self.zoom_out, width=3).pack(side=tk.RIGHT, padx=2)
        ttk.Button(toolbar_frame, text="+", command=self.zoom_in, width=3).pack(side=tk.RIGHT, padx=2)
        ttk.Button(toolbar_frame, text="Fit", command=self.fit_to_width, width=4).pack(side=tk.RIGHT, padx=5)
        
        self.zoom_label = ttk.Label(toolbar_frame, text="100%")
        self.zoom_label.pack(side=tk.RIGHT, padx=5)
        
        # Canvas with scrollbars
        canvas_frame = ttk.Frame(self.main_frame)
        canvas_frame.pack(fill=tk.BOTH, expand=True)
        
        v_scrollbar = ttk.Scrollbar(canvas_frame, orient=tk.VERTICAL)
        h_scrollbar = ttk.Scrollbar(canvas_frame, orient=tk.HORIZONTAL)
        
        self.canvas = tk.Canvas(
            canvas_frame,
            bg='white',
            yscrollcommand=v_scrollbar.set,
            xscrollcommand=h_scrollbar.set
        )
        
        v_scrollbar.config(command=self.canvas.yview)
        h_scrollbar.config(command=self.canvas.xview)
        
        v_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        h_scrollbar.pack(side=tk.BOTTOM, fill=tk.X)
        self.canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        # Mouse events
        self.canvas.bind("<MouseWheel>", self.on_mousewheel)
        self.canvas.bind("<Control-MouseWheel>", self.on_ctrl_mousewheel)
        
        self.show_placeholder()
        self.update_toggle_button()
        
    def toggle_view_mode(self):
        """Toggle between single page and continuous view"""
        self.is_continuous_mode = not self.is_continuous_mode
        self.update_toggle_button()
        self.on_mode_change()
        
    def update_toggle_button(self):
        """Update toggle button appearance based on current mode"""
        if self.is_continuous_mode:
            self.toggle_btn.config(text="Single Page")
        else:
            self.toggle_btn.config(text="Show All")
        
    def show_placeholder(self):
        """Show placeholder when no PDF is loaded"""
        self.canvas.delete("all")
        placeholder_text = "No PDF loaded\n\nSelect a file to begin"
        if self.is_continuous_mode:
            placeholder_text += "\n\nClick 'Single Page' to view one page at a time"
        else:
            placeholder_text += "\n\nClick 'Show All' to view all pages\nUse ◀ ▶ to navigate"
            
        self.canvas.create_text(
            self.width // 2, self.height // 2,
            text=placeholder_text,
            fill="gray",
            font=("Segoe UI", 12),
            justify=tk.CENTER
        )
        self.page_label.config(text="0 / 0")
        self.zoom_label.config(text="100%")
        
    def on_mode_change(self):
        """Handle mode change via toggle button"""
        # Show/hide navigation buttons
        if self.is_continuous_mode:
            self.nav_frame.pack_forget()
            self.canvas.configure(bg='#f0f0f0')
        else:
            self.nav_frame.pack(side=tk.LEFT, before=self.page_label)
            self.canvas.configure(bg='white')
        
        # Reload view if PDF is loaded
        if self.pdf_document:
            if self.is_continuous_mode:
                self.setup_continuous_view()
            else:
                self.render_current_page()
                
    def load_pdf(self, pdf_path):
        """Load PDF with current mode"""
        try:
            # Cancel any ongoing renders
            if self.current_render_future:
                self.current_render_future.cancel()
                
            # Clear cache when loading new PDF
            self.image_cache.clear()
            
            current_zoom = self.zoom_level
            
            if self.pdf_document:
                self.pdf_document.close()
                
            self.pdf_document = fitz.open(pdf_path)
            self.total_pages = len(self.pdf_document)
            self.current_page = 0
            
            if not hasattr(self, '_first_load_done'):
                self.zoom_level = 1.0
                self._first_load_done = True
            else:
                self.zoom_level = current_zoom
            
            if self.total_pages > 0:
                # Load appropriate view
                if self.is_continuous_mode:
                    self.setup_continuous_view()
                else:
                    self.render_current_page()
            else:
                self.show_placeholder()
                
            logger.info(f"Loaded PDF: {pdf_path} ({self.total_pages} pages)")
            
        except Exception as e:
            logger.error(f"Failed to load PDF {pdf_path}: {str(e)}")
            messagebox.showerror("PDF Error", f"Failed to load PDF:\n{str(e)}")
            self.show_placeholder()
    
    def setup_continuous_view(self):
        """Setup continuous view with max 10 pages"""
        if not self.pdf_document:
            return
            
        self.canvas.delete("all")
        self.rendered_pages.clear()
        self.page_positions.clear()
        self.page_heights.clear()
        
        # Limit pages for performance
        pages_to_render = min(self.total_pages, self.max_continuous_pages)
        
        # Calculate layout
        current_y = self.page_gap
        max_width = 0
        
        for page_num in range(pages_to_render):
            # Get page dimensions
            page = self.pdf_document[page_num]
            page_rect = page.rect
            
            render_width = int(page_rect.width * self.zoom_level)
            render_height = int(page_rect.height * self.zoom_level)
            
            # Store positions
            self.page_positions[page_num] = current_y
            self.page_heights[page_num] = render_height
            
            # Create placeholder
            canvas_width = self.canvas.winfo_width() or 400
            x_center = max(render_width // 2, canvas_width // 2)
            
            self.canvas.create_rectangle(
                x_center - render_width // 2, current_y,
                x_center + render_width // 2, current_y + render_height,
                fill='white',
                outline='#cccccc',
                width=1,
                tags=f"page_{page_num}"
            )
            
            # Page number
            self.canvas.create_text(
                x_center, current_y + render_height // 2,
                text=f"Page {page_num + 1}",
                fill="lightgray",
                font=("Segoe UI", 16),
                tags=f"page_{page_num}_label"
            )
            
            current_y += render_height + self.page_gap
            max_width = max(max_width, render_width)
        
        # Set scroll region
        self.canvas.configure(scrollregion=(0, 0, max_width, current_y))
        
        # Render all pages
        for page_num in range(pages_to_render):
            self.render_page_async(page_num, continuous_mode=True)
        
        # Update UI
        if pages_to_render < self.total_pages:
            self.page_label.config(text=f"Showing {pages_to_render} / {self.total_pages}")
        else:
            self.page_label.config(text=f"All {self.total_pages} pages")
        self.zoom_label.config(text=f"{int(self.zoom_level * 100)}%")
    
    def _get_cache_key(self, page_num, zoom):
        """Generate cache key for rendered page"""
        pdf_id = id(self.pdf_document) if self.pdf_document else 0
        return f"{pdf_id}_{page_num}_{zoom:.2f}"
    
    def render_page_async(self, page_num, continuous_mode=False):
        """Render page asynchronously"""
        cache_key = self._get_cache_key(page_num, self.zoom_level)
        
        # Check cache first
        cached_image = self.image_cache.get(cache_key)
        if cached_image:
            if continuous_mode:
                self.display_continuous_page(page_num, cached_image)
            else:
                self._display_rendered_image(cached_image, page_num)
            return
        
        def render_worker():
            try:
                page = self.pdf_document[page_num]
                mat = fitz.Matrix(self.zoom_level, self.zoom_level)
                pix = page.get_pixmap(matrix=mat, alpha=False)
                img_data = pix.tobytes("ppm")
                pix = None  # Free pixmap memory ASAP
                
                pil_image = Image.open(io.BytesIO(img_data))
                
                # Cache the rendered image
                self.image_cache.put(cache_key, pil_image)
                
                # Display on main thread
                if continuous_mode:
                    self.parent.after(0, lambda: self.display_continuous_page(page_num, pil_image))
                else:
                    self.parent.after(0, lambda: self._display_rendered_image(pil_image, page_num))
                    
            except Exception as e:
                logger.error(f"Background render error: {e}")
                
        future = self.render_executor.submit(render_worker)
        return future
    
    def display_continuous_page(self, page_num, pil_image):
        """Display page in continuous view"""
        try:
            if page_num not in self.page_positions:
                return
                
            photo = ImageTk.PhotoImage(pil_image)
            
            # Calculate position
            page_top = self.page_positions[page_num]
            canvas_width = self.canvas.winfo_width() or 400
            x_center = max(pil_image.width // 2, canvas_width // 2)
            
            # Remove placeholder
            self.canvas.delete(f"page_{page_num}")
            self.canvas.delete(f"page_{page_num}_label")
            
            # Display image
            self.canvas.create_image(
                x_center, page_top + pil_image.height // 2,
                image=photo,
                tags=f"page_{page_num}_image"
            )
            
            self.rendered_pages[page_num] = photo  # Prevent GC
            
        except Exception as e:
            logger.error(f"Error displaying continuous page {page_num}: {e}")
    
    def _display_rendered_image(self, pil_image, page_num):
        """Display rendered image on canvas (single page mode)"""
        if page_num != self.current_page or not pil_image:
            return
            
        try:
            # Convert to PhotoImage
            photo = ImageTk.PhotoImage(pil_image)
            
            # Clear canvas and display image
            self.canvas.delete("all")
            
            canvas_width = self.canvas.winfo_width()
            canvas_height = self.canvas.winfo_height()
            img_width = pil_image.width
            img_height = pil_image.height
            
            x = max(0, (canvas_width - img_width) // 2)
            y = max(0, (canvas_height - img_height) // 2)
            
            self.canvas.create_image(x, y, anchor=tk.NW, image=photo)
            self.canvas.configure(scrollregion=(0, 0, img_width, img_height))
            
            # Keep reference to prevent garbage collection
            self.current_photo = photo
            
            self.page_label.config(text=f"{self.current_page + 1} / {self.total_pages}")
            self.zoom_label.config(text=f"{int(self.zoom_level * 100)}%")
            
        except Exception as e:
            logger.error(f"Error displaying image: {e}")
    
    def render_current_page(self):
        """Render current page with caching (single page mode)"""
        if not self.pdf_document or self.current_page >= self.total_pages:
            return
            
        cache_key = self._get_cache_key(self.current_page, self.zoom_level)
        
        # Try cache first
        cached_image = self.image_cache.get(cache_key)
        if cached_image:
            self._display_rendered_image(cached_image, self.current_page)
            return
            
        # Show loading indicator
        self.canvas.delete("all")
        self.canvas.create_text(
            self.width // 2, self.height // 2,
            text="Rendering...",
            fill="gray",
            font=("Segoe UI", 10)
        )
        
        # Render in background
        self.current_render_future = self.render_page_async(self.current_page, continuous_mode=False)
    
    def prev_page(self):
        """Navigate to previous page"""
        if self.pdf_document and self.current_page > 0:
            self.current_page -= 1
            self.render_current_page()
            
    def next_page(self):
        """Navigate to next page"""
        if self.pdf_document and self.current_page < self.total_pages - 1:
            self.current_page += 1
            self.render_current_page()
    
    def zoom_in(self):
        """Increase zoom level"""
        if self.zoom_level < self.max_zoom:
            self.zoom_level = min(self.zoom_level * 1.2, self.max_zoom)
            self.refresh_view()
            
    def zoom_out(self):
        """Decrease zoom level"""
        if self.zoom_level > self.min_zoom:
            self.zoom_level = max(self.zoom_level / 1.2, self.min_zoom)
            self.refresh_view()
            
    def fit_to_width(self):
        """Fit current page to canvas width"""
        if not self.pdf_document:
            return
            
        try:
            page = self.pdf_document[self.current_page]
            page_rect = page.rect
            canvas_width = self.canvas.winfo_width()
            
            if canvas_width > 0 and page_rect.width > 0:
                self.zoom_level = (canvas_width - 20) / page_rect.width
                self.zoom_level = max(self.min_zoom, min(self.zoom_level, self.max_zoom))
                self.refresh_view()
        except Exception as e:
            logger.error(f"Error fitting to width: {str(e)}")
    
    def refresh_view(self):
        """Refresh view after zoom change"""
        if not self.pdf_document:
            return
        
        # Clear cache
        self.image_cache.clear()
        self.rendered_pages.clear()
        
        if self.is_continuous_mode:
            self.setup_continuous_view()
        else:
            self.render_current_page()
    
    def on_mousewheel(self, event):
        """Handle mouse wheel scrolling"""
        if self.is_continuous_mode:
            # Scroll in continuous mode
            if event.num == 4 or event.delta > 0:
                self.canvas.yview_scroll(-1, "units")
            elif event.num == 5 or event.delta < 0:
                self.canvas.yview_scroll(1, "units")
        else:
            # Navigate pages in single mode
            if event.num == 4 or event.delta > 0:
                self.prev_page()
            elif event.num == 5 or event.delta < 0:
                self.next_page()
    
    def on_ctrl_mousewheel(self, event):
        """Handle Ctrl+mouse wheel for zooming"""
        if event.num == 4 or event.delta > 0:
            self.zoom_in()
        elif event.num == 5 or event.delta < 0:
            self.zoom_out()
    
    def close_pdf(self):
        """Close PDF and cleanup resources"""
        if self.current_render_future:
            self.current_render_future.cancel()
            
        if self.pdf_document:
            self.pdf_document.close()
            self.pdf_document = None
            
        self.image_cache.clear()
        self.rendered_pages.clear()
        self.page_positions.clear()
        self.page_heights.clear()
        self.show_placeholder()
        
    def __del__(self):
        """Cleanup on destruction"""
        try:
            self.render_executor.shutdown(wait=False)
        except:
            pass

class OptimizedFileManager:
    """File operations with performance optimizations"""
    
    @staticmethod
    def validate_filename(filename: str) -> str:
        """Clean filename for filesystem compatibility"""
        invalid_chars = r'[<>:"/\\|?*]'
        cleaned = re.sub(invalid_chars, '_', filename)
        if len(cleaned) > 200:
            name, ext = os.path.splitext(cleaned)
            cleaned = name[:196] + ext
        return cleaned

    @staticmethod
    @lru_cache(maxsize=128)
    def _cached_file_hash(filepath: str, size: int, mtime: float) -> str:
        """Cached hash calculation using file metadata"""
        hash_sha1 = hashlib.sha1()
        try:
            with open(filepath, "rb") as f:
                # Read in larger chunks for better performance
                while chunk := f.read(65536):  # 64KB chunks
                    hash_sha1.update(chunk)
        except Exception as e:
            logger.error(f"Hash calculation failed for {filepath}: {e}")
            return ""
        return hash_sha1.hexdigest()

    @staticmethod
    def verify_copy(source: str, destination: str) -> bool:
        """Fast file verification using size and hash"""
        try:
            src_stat = os.stat(source)
            dst_stat = os.stat(destination)
            
            # Quick size check first
            if src_stat.st_size != dst_stat.st_size:
                return False
                
            # Hash verification for smaller files only
            if src_stat.st_size < 50 * 1024 * 1024:  # 50MB threshold
                src_hash = OptimizedFileManager._cached_file_hash(
                    source, src_stat.st_size, src_stat.st_mtime
                )
                dst_hash = OptimizedFileManager._cached_file_hash(
                    destination, dst_stat.st_size, dst_stat.st_mtime
                )
                return src_hash == dst_hash
            
            return True  # Trust size check for large files
            
        except Exception as e:
            logger.error(f"Verification failed: {e}")
            return False

    @staticmethod
    def safe_copy_file(source: str, destination: str) -> bool:
        """Optimized file copy with verification"""
        if not os.path.exists(source):
            raise PDFIndexerError(f"Source not found: {source}")
            
        dest_dir = os.path.dirname(destination)
        os.makedirs(dest_dir, exist_ok=True)
        
        # Check disk space
        file_size = os.path.getsize(source)
        free_space = shutil.disk_usage(dest_dir).free
        if file_size > free_space - (50 * 1024 * 1024):  # 50MB buffer
            raise PDFIndexerError("Insufficient disk space")
        
        # Use copy2 for better performance
        shutil.copy2(source, destination)
        
        # Quick verification
        if not OptimizedFileManager.verify_copy(source, destination):
            try:
                os.remove(destination)
            except:
                pass
            raise PDFIndexerError("Copy verification failed")
        
        return True

    @staticmethod
    def safe_delete_file(path: str) -> bool:
        """Safely delete a file"""
        if os.path.exists(path):
            try:
                os.remove(path)
                return True
            except Exception as e:
                logger.error(f"Error deleting {path}: {str(e)}")
                return False
        return False

class OptimizedCSVManager:
    """CSV operations with performance optimizations and flexible column ordering"""
    REQUIRED_HEADERS = {"PN Number"}  # Only PN Number is strictly required
    ACCOUNT_NAME_VARIANTS = {"Account Name", "Name"}  # Accept either variant

    @staticmethod
    @lru_cache(maxsize=4)
    def load_and_validate_csv(filepath: str) -> pd.DataFrame:
        """Load and validate CSV with caching and flexible header matching"""
        if not os.path.exists(filepath):
            raise PDFIndexerError(f"File not found: {filepath}")
            
        try:
            # Use optimized pandas settings
            df = pd.read_csv(
                filepath, 
                dtype=str, 
                na_filter=False,
                engine='c'  # Use C engine for better performance
            )
        except Exception as e:
            raise PDFIndexerError(f"Error reading CSV: {str(e)}")
        
        logger.info(f"CSV loaded with columns in order: {list(df.columns)}")
        
        # Check for PN Number column (required)
        if "PN Number" not in df.columns:
            available_cols = ", ".join(f"'{col}'" for col in df.columns)
            raise PDFIndexerError(f"Missing required header: 'PN Number'. Available columns: {available_cols}")
        
        # Check for account name column (flexible)
        account_col = None
        for variant in OptimizedCSVManager.ACCOUNT_NAME_VARIANTS:
            if variant in df.columns:
                account_col = variant
                break
        
        if account_col is None:
            available_variants = " or ".join(f"'{v}'" for v in OptimizedCSVManager.ACCOUNT_NAME_VARIANTS)
            available_cols = ", ".join(f"'{col}'" for col in df.columns)
            raise PDFIndexerError(f"Missing account name header. Expected one of: {available_variants}. Available columns: {available_cols}")
        
        # Standardize the account column name
        if account_col != "Account Name":
            df = df.rename(columns={account_col: "Account Name"})
            logger.info(f"Renamed column '{account_col}' to 'Account Name' for internal consistency")
        
        # Reorder columns to standard format
        standard_columns = ["Account Name", "PN Number"]
        other_columns = [col for col in df.columns if col not in standard_columns]
        df = df[standard_columns + other_columns]
        
        logger.info(f"Standardized column order: {list(df.columns)}")
        
        # Clean and deduplicate data
        df = df.dropna(subset=["PN Number", "Account Name"])
        df["PN Number"] = df["PN Number"].astype(str).str.replace(r'^(\d+)\.0$', r'\1', regex=True)
        return df.drop_duplicates(subset=["PN Number"])

class DebouncedSearch:
    """Debounced search to avoid excessive filtering"""
    def __init__(self, delay_ms=300):
        self.delay_ms = delay_ms
        self.after_id = None
        
    def search(self, widget, callback):
        """Execute search after delay"""
        if self.after_id:
            widget.after_cancel(self.after_id)
        self.after_id = widget.after(self.delay_ms, callback)

class AccountLookup:
    """Optimized account lookup with indexing"""
    def __init__(self, accounts: List[str]):
        self.accounts = accounts
        self.account_index = {acc.lower(): acc for acc in accounts}
        self.name_index = {}
        
        # Build search index
        for acc in accounts:
            words = acc.lower().split('_')
            for word in words:
                if word not in self.name_index:
                    self.name_index[word] = []
                self.name_index[word].append(acc)
                
    def search(self, term: str) -> List[str]:
        """Fast search using pre-built indices"""
        if not term:
            return self.accounts
            
        term = term.lower().strip()
        
        # Direct match
        if term in self.account_index:
            return [self.account_index[term]]
            
        # Word-based search
        results = set()
        for word, matches in self.name_index.items():
            if term in word:
                results.update(matches)
                
        # Fallback to contains search
        if not results:
            results = {acc for acc in self.accounts if term in acc.lower()}
            
        return sorted(list(results))

class SetupWindow:
    """Initial setup dialog for application configuration"""
    def __init__(self, parent=None):
        self.root = tk.Toplevel(parent) if parent else tk.Tk()
        self.result = None
        self.setup_complete = False
        
        # Path variables
        self.doc_types_path = tk.StringVar(value="Not selected")
        self.accounts_path = tk.StringVar(value="Not selected")
        self.pdf_folder_path = tk.StringVar(value="Not selected")
        self.output_folder_path = tk.StringVar(value="Not selected")
        
        # Full path storage
        self.full_doc_types_path = None
        self.full_accounts_path = None
        self.full_pdf_folder_path = None
        self.full_output_folder_path = None
        
        self.create_setup_window()
        
    def create_setup_window(self):
        """Create the setup UI"""
        self.root.title("FileForge v8.8")
        self.root.geometry("450x340")
        self.root.resizable(False, False)
        
        # Try to set icon
        self._set_window_icon()
        
        # Center window
        self._center_window()
        
        # Configure styles and colors
        self._configure_styles()
        
        # Create main frame
        main_frame = ttk.Frame(self.root, padding=10)
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Title
        ttk.Label(main_frame, text="Setup Requirements", style="Header.TLabel").pack(pady=(0, 10))
        
        # File selection sections
        self.create_compact_section(main_frame, "Document Types CSV", self.doc_types_path, self.browse_doc_types)
        self.create_compact_section(main_frame, "Accounts CSV", self.accounts_path, self.browse_accounts)
        self.create_compact_section(main_frame, "Scanned PDFs Folder", self.pdf_folder_path, self.browse_pdf_folder)
        self.create_compact_section(main_frame, "Output Folder", self.output_folder_path, self.browse_output_folder)
        
        # Buttons
        self._create_button_frame(main_frame)
        
        # Event handlers
        self.root.protocol("WM_DELETE_WINDOW", self.cancel)
        
    def _set_window_icon(self):
        """Set window icon if available"""
        try:
            # Get icon path relative to script location
            if getattr(sys, 'frozen', False):
                # Running as compiled exe
                application_path = sys._MEIPASS
            else:
                # Running as Python script
                application_path = os.path.dirname(os.path.abspath(__file__))
            
            icon_path = os.path.join(application_path, "test.ico")
            
            if os.path.exists(icon_path):
                self.root.iconbitmap(icon_path)
        except Exception:
            pass  # Continue without icon if there's an issue
            
    def _center_window(self):
        """Center the window on screen"""
        self.root.update_idletasks()
        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()
        x = (screen_width // 2) - (450 // 2)
        y = (screen_height // 2) - (340 // 2)
        self.root.geometry(f"450x340+{x}+{y}")
        
    def _configure_styles(self):
        """Configure ttk styles"""
        # Colors
        bg_color = "#304056"
        text_color = "#ffffff"
        primary_color = "#FEC80B"
        secondary_color = "#1D421E"
        
        self.root.configure(bg=bg_color)
        
        # Styles
        style = ttk.Style()
        style.theme_use("clam")
        style.configure("TFrame", background=bg_color)
        style.configure("Header.TLabel", font=("Segoe UI", 14, 'bold'), 
                       foreground=text_color, background=bg_color)
        style.configure("TLabel", font=("Segoe UI", 9), 
                       background=bg_color, foreground=text_color)
        style.configure("File.TLabel", font=("Segoe UI", 9), 
                       background=bg_color, foreground=primary_color, padding=(0, 0, 0, 5))
        style.configure("TButton", font=("Segoe UI", 9), padding=4, 
                       background=primary_color, foreground="#333333", 
                       borderwidth=0, focusthickness=0, relief="flat")
        style.map("TButton", background=[('active', '#e6b710'), ('pressed', '#d0a30e')])
        style.configure("Secondary.TButton", font=("Segoe UI", 9), padding=4, 
                       background=secondary_color, foreground=text_color, 
                       borderwidth=0, focusthickness=0, relief="flat")
        style.map("Secondary.TButton", 
                 background=[('active', '#1a3a1a'), ('pressed', '#163216')])
        
    def _create_button_frame(self, parent):
        """Create button frame with Cancel and Start buttons"""
        button_frame = ttk.Frame(parent)
        button_frame.pack(fill=tk.X, pady=(10, 0))
        
        ttk.Button(button_frame, text="Cancel", command=self.cancel, 
                  style="Secondary.TButton", width=10).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="Start", command=self.validate_and_start, 
                  style="TButton", width=10).pack(side=tk.RIGHT, padx=5)
                  
        credit_frame = ttk.Frame(parent)
        credit_frame.pack(fill=tk.X, pady=(5, 0))
        bg_color = "#304056"
        ttk.Label(credit_frame, text="Developed by KTFajardo", font=("Segoe UI", 8), foreground="#cccccc", background=bg_color, anchor=tk.CENTER).pack(fill=tk.X)
        
    def create_compact_section(self, parent, title, path_var, browse_command):
        """Create a file/folder selection section"""
        section_frame = ttk.Frame(parent)
        section_frame.pack(fill=tk.X, pady=(0, 8))
        
        title_frame = ttk.Frame(section_frame)
        title_frame.pack(fill=tk.X)
        
        ttk.Label(title_frame, text=f"{title}:", style="TLabel").pack(side=tk.LEFT, padx=(0, 5))
        
        name_label = ttk.Label(title_frame, textvariable=path_var, 
                              style="File.TLabel", cursor="hand2")
        name_label.pack(side=tk.LEFT, fill=tk.X, expand=True)
        name_label.bind("<Button-1>", lambda e: browse_command())
        
        ttk.Button(title_frame, text="Browse...", command=browse_command, 
                  style="TButton", width=8).pack(side=tk.RIGHT)
        
    def browse_doc_types(self):
        """Browse for document types CSV file"""
        filepath = filedialog.askopenfilename(
            title="Select Document Types CSV", 
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")], 
            parent=self.root
        )
        if filepath:
            self.doc_types_path.set(os.path.basename(filepath))
            self.full_doc_types_path = filepath
            
    def browse_accounts(self):
        """Browse for accounts CSV file"""
        filepath = filedialog.askopenfilename(
            title="Select Accounts CSV", 
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")], 
            parent=self.root
        )
        if filepath:
            self.accounts_path.set(os.path.basename(filepath))
            self.full_accounts_path = filepath
            
    def browse_pdf_folder(self):
        """Browse for PDF folder"""
        folderpath = filedialog.askdirectory(
            title="Select Folder with Scanned PDFs", 
            parent=self.root
        )
        if folderpath:
            self.pdf_folder_path.set(os.path.basename(folderpath))
            self.full_pdf_folder_path = folderpath
            
    def browse_output_folder(self):
        """Browse for output folder"""
        folderpath = filedialog.askdirectory(
            title="Select Output Folder for Renamed Files", 
            parent=self.root
        )
        if folderpath:
            self.output_folder_path.set(os.path.basename(folderpath))
            self.full_output_folder_path = folderpath
            
    def validate_and_start(self):
        """Validate selections and start application"""
        paths = [
            (self.full_doc_types_path, "Document Types CSV"),
            (self.full_accounts_path, "Accounts CSV"),
            (self.full_pdf_folder_path, "Scanned PDFs Folder"),
            (self.full_output_folder_path, "Output Folder")
        ]
        
        # Check if all paths are selected
        for path, name in paths:
            if not path:
                messagebox.showerror("Missing Selection", f"Please select {name}", parent=self.root)
                return
                
        # Check if paths exist
        for path, name in paths:
            if not os.path.exists(path):
                messagebox.showerror("Path Not Found", f"{name} does not exist:\n{path}", parent=self.root)
                return
                
        try:
            # Quick validation
            doc_df = pd.read_csv(self.full_doc_types_path, nrows=1)
            if doc_df.empty:
                messagebox.showerror("Invalid File", "Document Types CSV is empty", parent=self.root)
                return
                
            OptimizedCSVManager.load_and_validate_csv(self.full_accounts_path)
            
            # Quick PDF check
            pdf_count = sum(1 for f in os.listdir(self.full_pdf_folder_path) 
                          if f.lower().endswith('.pdf'))
            if pdf_count == 0:
                messagebox.showerror("No PDFs Found", "No PDF files found in the selected folder", parent=self.root)
                return
                
        except Exception as e:
            messagebox.showerror("Validation Error", f"Error validating files:\n{str(e)}", parent=self.root)
            return
            
        self.result = {
            'doc_types_csv': self.full_doc_types_path,
            'accounts_csv': self.full_accounts_path,
            'pdf_folder': self.full_pdf_folder_path,
            'output_folder': self.full_output_folder_path
        }
        self.setup_complete = True
        self.root.destroy()
        
    def cancel(self):
        """Cancel setup"""
        self.root.destroy()
        
    def show(self):
        """Show dialog and return result"""
        self.root.grab_set()
        self.root.wait_window()
        return self.result if self.setup_complete else None

class OptimizedSearchDialog:
    """Fast account search dialog with debouncing"""
    def __init__(self, parent, accounts: List[str], initial_selection: str = ""):
        self.parent = parent
        self.account_lookup = AccountLookup(accounts)
        self.result = None
        self.debounced_search = DebouncedSearch(delay_ms=250)
        
        self.dialog = tk.Toplevel(parent)
        self.dialog.title("Search Accounts")
        self.dialog.transient(parent)
        self.dialog.grab_set()
        self.dialog.resizable(False, False)
        
        self._setup_ui()
        
    def _setup_ui(self):
        """Setup the search dialog UI"""
        # Set icon
        try:
            if getattr(sys, 'frozen', False):
                application_path = sys._MEIPASS
            else:
                application_path = os.path.dirname(os.path.abspath(__file__))
            
            icon_path = os.path.join(application_path, "test.ico")
            if os.path.exists(icon_path):
                self.dialog.iconbitmap(icon_path)
        except Exception:
            pass
        
        # Colors and styling
        bg_color = "#304056"
        text_color = "#ffffff"
        highlight_color = "#FEC80B"
        self.dialog.configure(bg=bg_color)
        
        # Position dialog
        self.dialog.update_idletasks()
        x = self.parent.winfo_x() + (self.parent.winfo_width() // 2) - 200
        y = self.parent.winfo_y() + (self.parent.winfo_height() // 2) - 150
        self.dialog.geometry(f"400x300+{x}+{y}")
        
        # Main frame
        main_frame = ttk.Frame(self.dialog, padding=15)
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Search label and entry
        ttk.Label(main_frame, text="Search:", style="TLabel").pack(anchor=tk.W, pady=(0, 5))
        
        self.search_var = tk.StringVar()
        search_entry = ttk.Entry(main_frame, textvariable=self.search_var, font=("Segoe UI", 10))
        search_entry.pack(fill=tk.X, pady=(0, 10))
        search_entry.focus_set()
        
        # Results frame with scrollbar
        results_frame = ttk.Frame(main_frame)
        results_frame.pack(fill=tk.BOTH, expand=True)
        
        scrollbar = ttk.Scrollbar(results_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        self.listbox = tk.Listbox(
            results_frame,
            yscrollcommand=scrollbar.set,
            bg="#405c7c",
            fg=text_color,
            selectbackground=highlight_color,
            selectforeground="#000000",
            font=("Segoe UI", 9),
            height=10,
            borderwidth=1,
            relief="solid"
        )
        self.listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.config(command=self.listbox.yview)
        
        # Initial population
        self.update_results()
        
        # Buttons
        btn_frame = ttk.Frame(main_frame)
        btn_frame.pack(fill=tk.X, pady=(10, 0))
        
        ttk.Button(btn_frame, text="Cancel", command=self.cancel, 
                  style="Secondary.TButton", width=10).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(btn_frame, text="Select", command=self.select, 
                  style="TButton", width=10).pack(side=tk.RIGHT)
        
        # Event bindings
        search_entry.bind('<KeyRelease>', self.on_search)
        self.listbox.bind('<Double-1>', lambda e: self.select())
        self.listbox.bind('<Return>', lambda e: self.select())
        self.dialog.bind('<Escape>', lambda e: self.cancel())
    
    def on_search(self, event):
        """Handle search with debouncing"""
        self.debounced_search.search(self.dialog, self.update_results)
    
    def update_results(self):
        """Update listbox with optimized search"""
        search_term = self.search_var.get()
        filtered = self.account_lookup.search(search_term)
        
        self.listbox.delete(0, tk.END)
        for acc in filtered[:100]:  # Limit results for performance
            self.listbox.insert(tk.END, acc)
    
    def select(self):
        """Select current item"""
        selection = self.listbox.curselection()
        if selection:
            self.result = self.listbox.get(selection[0])
            self.dialog.destroy()
    
    def cancel(self):
        """Cancel dialog"""
        self.dialog.destroy()
    
    def show(self):
        """Show dialog and return result"""
        self.dialog.wait_window()
        return self.result

class PDFIndexer:
    """Main application class with performance optimizations"""
    def __init__(self):
        self.root = None
        self.pdf_viewer = None
        self.doc_types_csv = None
        self.document_types: List[str] = []
        self.accounts_csv = None
        self.accounts_df = None
        self.pdf_folder = None
        self.output_folder = None
        self.pdf_files: List[str] = []
        self.current_pdf_index = 0
        self.rename_history: List[RenameOperation] = []
        self.return_index: int = None
        self.selected_account = None
        self.document_type = None
        self.status_var = None
        self.title_label = None
        self.current_file_label = None
        self.output_folder_label = None
        self.account_display_to_pn: Dict[str, str] = {}
        self.operation_to_correct: RenameOperation = None
        self.account_combo = None
        self.position_label = None
        self.account_lookup = None
        
        self.setup_logging()
        
    def setup_logging(self):
        """Configure session logging"""
        log_dir = Path('logs')
        try:
            log_dir.mkdir(exist_ok=True)
            session_log = log_dir / f"session_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"
            
            fh = logging.FileHandler(session_log)
            fh.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))
            
            root_logger = logging.getLogger()
            root_logger.setLevel(logging.INFO)
            root_logger.addHandler(fh)
            
            if not any(isinstance(h, logging.StreamHandler) for h in root_logger.handlers):
                root_logger.addHandler(logging.StreamHandler())
                
            logger.info(f"Session log started: {session_log}")
        except Exception as e:
            print(f"Log setup failed: {str(e)}")

    def set_window_icon(self, window):
        """Set window icon using .ico file"""
        try:
            # Get the correct path whether running as script or exe
            if getattr(sys, 'frozen', False):
                # Running as compiled exe
                application_path = sys._MEIPASS
            else:
                # Running as Python script
                application_path = os.path.dirname(os.path.abspath(__file__))
            
            icon_path = os.path.join(application_path, "test.ico")
            
            if os.path.exists(icon_path):
                window.iconbitmap(icon_path)
                logger.info(f"Icon set successfully: {icon_path}")
            else:
                logger.warning(f"Icon file not found: {icon_path}")
                
        except Exception as e:
            logger.warning(f"Could not set window icon: {str(e)}")

    def initialize_application(self) -> bool:
        """Initialize application with setup dialog"""
        setup_window = SetupWindow()
        setup_paths = setup_window.show()
        
        if not setup_paths:
            return False
            
        self.root = tk.Tk()
        self.root.withdraw()
        self.selected_account = tk.StringVar(self.root)
        self.document_type = tk.StringVar(self.root)
        self.status_var = tk.StringVar(self.root, value='Ready')
        
        self.doc_types_csv = setup_paths['doc_types_csv']
        self.accounts_csv = setup_paths['accounts_csv']
        self.pdf_folder = setup_paths['pdf_folder']
        self.output_folder = setup_paths['output_folder']
        
        try:
            # Load document types
            df = pd.read_csv(self.doc_types_csv, dtype=str)
            self.document_types = [str(v).strip() for v in df.iloc[:,0].unique() if str(v).strip()]
            if not self.document_types:
                raise PDFIndexerError("Document Types CSV is empty or invalid")
                
            # Load accounts with optimization
            self.accounts_df = OptimizedCSVManager.load_and_validate_csv(self.accounts_csv)
            self.account_display_to_pn = {}
            accounts_list = []
            
            for _, r in self.accounts_df.iterrows():
                display = f"{r['Account Name']}_{r['PN Number']}"
                self.account_display_to_pn[display] = r['PN Number']
                accounts_list.append(display)
                
            # Create optimized account lookup
            self.account_lookup = AccountLookup(accounts_list)
                
            # Load PDF files
            self.pdf_files = sorted(
                [f for f in os.listdir(self.pdf_folder) if f.lower().endswith('.pdf')],
                key=natural_key
            )
            if not self.pdf_files:
                raise PDFIndexerError("No PDF files found in selected directory")
                
        except Exception as e:
            messagebox.showerror("Initialization Error", str(e))
            return False
            
        return True

    def create_gui(self):
        """Create main application GUI"""
        self.root.deiconify()
        self.root.title("FileForge v8.8")
        self.root.geometry("1200x700")
        self.root.protocol("WM_DELETE_WINDOW", self.on_closing)
        self.set_window_icon(self.root)
        
        # Configure colors and styles
        self._configure_main_styles()
        
        # Main layout
        main_paned = ttk.PanedWindow(self.root, orient=tk.HORIZONTAL)
        main_paned.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        control_frame = ttk.Frame(main_paned, padding=10)
        main_paned.add(control_frame, weight=1)
        
        pdf_frame = ttk.Frame(main_paned)
        main_paned.add(pdf_frame, weight=2)
        
        # PDF viewer
        self.pdf_viewer = TogglePDFViewer(pdf_frame)
        
        # Control panel
        self._create_control_panel(control_frame)
        
        # Status bar
        self._create_status_bar()
        
        # Event bindings
        self._setup_event_bindings()
        
        self.load_current_pdf()

    def _configure_main_styles(self):
        """Configure main application styles"""
        # Colors
        bg_color = "#304056"
        text_color = "#ffffff"
        primary_color = "#FEC80B"
        secondary_color = "#1D421E"
        
        self.root.configure(bg=bg_color)
        
        # Styles
        style = ttk.Style()
        style.theme_use("clam")
        style.configure("TFrame", background=bg_color)
        style.configure("Header.TLabel", font=("Segoe UI", 14, 'bold'), 
                       foreground=text_color, background=bg_color)
        style.configure("TLabel", font=("Segoe UI", 9), 
                       background=bg_color, foreground=text_color)
        style.configure("TButton", font=("Segoe UI", 9, 'bold'), padding=4, 
                       borderwidth=0, background=primary_color, foreground="#333333", 
                       focusthickness=0, focuscolor="none", relief="flat", width=15)
        style.map("TButton", background=[('active', '#e6b710'), ('pressed', '#d0a30e')])
        style.configure("Secondary.TButton", font=("Segoe UI", 9, 'bold'), padding=4, 
                       background=secondary_color, foreground=text_color, 
                       borderwidth=0, focusthickness=0, relief="flat", width=15)
        style.map("Secondary.TButton", 
                 background=[('active', '#1a3a1a'), ('pressed', '#163216')])
        style.configure("TCombobox", font=("Segoe UI", 10), padding=4, 
                       fieldbackground="#405c7c", foreground="#ffffff", 
                       background=bg_color, selectbackground=primary_color, 
                       selectforeground="#333333", insertcolor="#ffffff", 
                       borderwidth=1, relief="solid")
        style.map('TCombobox', 
                 foreground=[('readonly', '#ffffff'), ('active', '#ffffff'), ('disabled', '#aaaaaa')], 
                 fieldbackground=[('readonly', '#405c7c'), ('focus', '#4a6490'), ('active', '#4a6490')], 
                 selectbackground=[('readonly', '#405c7c')], 
                 selectforeground=[('readonly', '#ffffff'), ('active', '#333333')], 
                 relief=[('focus', 'solid'), ('!focus', 'solid')])

    def _create_control_panel(self, parent):
        """Create the control panel UI"""
        # Title
        title_frame = ttk.Frame(parent)
        title_frame.pack(fill=tk.X, pady=(0, 10))
        
        self.title_label = ttk.Label(title_frame, text="Select an account to begin", 
                                   style="Header.TLabel", anchor=tk.CENTER)
        self.title_label.pack(fill=tk.X)
        
        # Account selection
        self._create_account_selection(parent)
        
        # Document type selection
        self._create_document_type_selection(parent)
        
        # Buttons
        self._create_button_panel(parent)
        
        # File info
        self._create_file_info_panel(parent)

    def _create_account_selection(self, parent):
        """Create account selection section"""
        account_frame = ttk.Frame(parent)
        account_frame.pack(fill=tk.X, pady=(0, 8))
        
        ttk.Label(account_frame, text="Account:", style="TLabel").pack(anchor=tk.W, pady=(0, 3))
        
        account_input_frame = ttk.Frame(account_frame)
        account_input_frame.pack(fill=tk.X, ipady=3)
        
        accounts = list(self.account_display_to_pn.keys())
        account_combo = ttk.Combobox(account_input_frame, textvariable=self.selected_account, 
                                   values=accounts, state='readonly', height=12, 
                                   style="TCombobox", width=20)
        account_combo.pack(side=tk.LEFT, fill=tk.X, expand=True, ipady=2)
        
        search_btn = ttk.Button(account_input_frame, text="Search", width=6, 
                              command=self.open_account_search, style="Secondary.TButton")
        search_btn.pack(side=tk.RIGHT, padx=(5, 0))
        
        self.account_combo = self.create_account_combo_wrapper(accounts, account_combo)
        
        self.position_label = ttk.Label(account_frame, text="", font=("Segoe UI", 8), 
                                      foreground="#FEC80B", background="#304056", anchor=tk.W)
        self.position_label.pack(fill=tk.X, pady=(2, 0))

    def _create_document_type_selection(self, parent):
        """Create document type selection section"""
        doc_frame = ttk.Frame(parent)
        doc_frame.pack(fill=tk.X, pady=(0, 10))
        
        ttk.Label(doc_frame, text="Document Type:", style="TLabel").pack(anchor=tk.W, pady=(0, 3))
        
        doc_input_frame = ttk.Frame(doc_frame)
        doc_input_frame.pack(fill=tk.X)
        
        self.document_type_combobox = ttk.Combobox(doc_input_frame, textvariable=self.document_type, 
                                                 values=self.document_types, state='readonly', 
                                                 height=12, style="TCombobox", width=20)
        self.document_type_combobox.pack(side=tk.LEFT, fill=tk.X, expand=True, ipady=2)
        
        add_btn = ttk.Button(doc_input_frame, text="+ Add", width=6, 
                           command=self.add_document_type, style="Secondary.TButton")
        add_btn.pack(side=tk.RIGHT, padx=(5, 0))

    def _create_button_panel(self, parent):
        """Create button panel"""
        button_frame = ttk.Frame(parent)
        button_frame.pack(fill=tk.X, pady=(15, 0))
        
        # Row 1
        row1_frame = ttk.Frame(button_frame)
        row1_frame.pack(fill=tk.X, pady=(0, 8))
        
        ttk.Button(row1_frame, text='Next Account', command=self.next_account, 
                  style="TButton").pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 4))
        ttk.Button(row1_frame, text='Rename & Next', command=self.rename_and_next, 
                  style="TButton").pack(side=tk.RIGHT, fill=tk.X, expand=True, padx=(4, 0))
        
        # Row 2
        row2_frame = ttk.Frame(button_frame)
        row2_frame.pack(fill=tk.X, pady=(0, 8))
        
        ttk.Button(row2_frame, text='Back', command=self.go_back, 
                  style="Secondary.TButton").pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 4))
        ttk.Button(row2_frame, text='Skip', command=self.skip_file, 
                  style="Secondary.TButton").pack(side=tk.RIGHT, fill=tk.X, expand=True, padx=(4, 0))
        
        # Row 3
        row3_frame = ttk.Frame(button_frame)
        row3_frame.pack(fill=tk.X, pady=(0, 15))
        
        ttk.Button(row3_frame, text='Jump to File', command=self.open_history_window, 
                  style="Secondary.TButton").pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 4))
        ttk.Button(row3_frame, text='Export History', command=self.export_history, 
                  style="Secondary.TButton").pack(side=tk.RIGHT, fill=tk.X, expand=True, padx=(4, 0))

    def _create_file_info_panel(self, parent):
        """Create file info panel"""
        info_frame = ttk.Frame(parent)
        info_frame.pack(fill=tk.X, side=tk.BOTTOM, pady=(10, 0))
        
        self.current_file_label = ttk.Label(info_frame, text="", style="TLabel", 
                                          wraplength=300, anchor=tk.W, justify=tk.LEFT)
        self.current_file_label.pack(fill=tk.X, pady=(0, 5))
        
        output_frame = ttk.Frame(info_frame)
        output_frame.pack(fill=tk.X)
        
        ttk.Label(output_frame, text="Output:", style="TLabel").pack(side=tk.LEFT)
        
        self.output_folder_label = ttk.Label(output_frame, text=os.path.basename(self.output_folder), 
                                           font=("Segoe UI", 8), foreground="#FEC80B", cursor="hand2")
        self.output_folder_label.pack(side=tk.LEFT, padx=(3, 0))
        
        self.output_folder_label.bind("<Button-1>", lambda e: self.open_output_folder())
        self.output_folder_label.bind("<Enter>", lambda e: self.output_folder_label.config(foreground="#ffffff"))
        self.output_folder_label.bind("<Leave>", lambda e: self.output_folder_label.config(foreground="#FEC80B"))

    def _create_status_bar(self):
        """Create status bar"""
        status_frame = ttk.Frame(self.root, padding=(8, 4))
        status_frame.pack(fill=tk.X, side=tk.BOTTOM)
        
        status_label = ttk.Label(status_frame, textvariable=self.status_var, anchor=tk.W)
        status_label.pack(side=tk.LEFT, fill=tk.X, expand=True)
        
        developer_label = ttk.Label(status_frame, text="Developed by KTFajardo", style="Status.TLabel", anchor=tk.E)
        developer_label.pack(side=tk.RIGHT)

    def _setup_event_bindings(self):
        """Setup keyboard and event bindings"""
        # Variable traces
        self.selected_account.trace_add('write', lambda *a: self.update_title_and_position())
        
        # Keyboard shortcuts
        self.root.bind('<Tab>', lambda e: self.next_account())
        self.root.bind('<Shift-Tab>', lambda e: self.previous_account())
        self.root.bind('<Return>', lambda e: self.rename_and_next())
        self.root.bind('<Control-z>', lambda e: self.go_back())
        self.root.bind('<Control-h>', lambda e: self.open_history_window())
        self.root.bind('<Control-s>', lambda e: self.export_history())
        self.root.bind('<Control-S>', lambda e: self.export_history())
        self.root.bind('<Left>', lambda e: self.pdf_viewer.prev_page())
        self.root.bind('<Right>', lambda e: self.pdf_viewer.next_page())
        self.root.bind('<Prior>', lambda e: self.pdf_viewer.prev_page())
        self.root.bind('<Next>', lambda e: self.pdf_viewer.next_page())
        self.root.bind('<Control-plus>', lambda e: self.pdf_viewer.zoom_in())
        self.root.bind('<Control-minus>', lambda e: self.pdf_viewer.zoom_out())
        self.root.bind('<Control-0>', lambda e: self.pdf_viewer.fit_to_width())
        self.root.bind('<d>', lambda e: self.cycle_document_type())
        self.root.bind('<D>', lambda e: self.cycle_document_type())
        self.root.bind('<a>', lambda e: self.previous_document_type())
        self.root.bind('<A>', lambda e: self.previous_document_type())

    def add_document_type(self):
        """Add new document type"""
        dialog = tk.Toplevel(self.root)
        dialog.title("Add Document Type")
        dialog.transient(self.root)
        dialog.grab_set()
        dialog.resizable(False, False)
        
        bg_color = "#304056"
        text_color = "#ffffff"
        secondary_color = "#1D421E"
        dialog.configure(bg=bg_color)
        
        dialog.update_idletasks()
        x = self.root.winfo_x() + (self.root.winfo_width() // 2) - 150
        y = self.root.winfo_y() + (self.root.winfo_height() // 2) - 60
        dialog.geometry(f"300x120+{x}+{y}")
        
        style = ttk.Style(dialog)
        style.configure("Dialog.TLabel", background=bg_color, foreground=text_color, font=("Segoe UI", 9))
        style.configure("Dialog.TButton", background=secondary_color, foreground=text_color, font=("Segoe UI", 9))
        style.map("Dialog.TButton", background=[('active', '#1a3a1a'), ('pressed', '#163216')])
        
        main_frame = ttk.Frame(dialog, padding=15)
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        ttk.Label(main_frame, text="Enter new document type:", style="Dialog.TLabel").pack(anchor=tk.W, pady=(0, 8))
        
        entry_var = tk.StringVar()
        entry = ttk.Entry(main_frame, textvariable=entry_var, font=("Segoe UI", 10), width=30)
        entry.pack(fill=tk.X, pady=(0, 15))
        entry.focus_set()
        
        btn_frame = ttk.Frame(main_frame)
        btn_frame.pack(fill=tk.X)
        
        def on_ok():
            dialog.result = entry_var.get().strip()
            dialog.destroy()
            
        def on_cancel():
            dialog.result = None
            dialog.destroy()
            
        ttk.Button(btn_frame, text="OK", command=on_ok, style="Dialog.TButton", width=8).pack(side=tk.RIGHT, padx=(5, 0))
        ttk.Button(btn_frame, text="Cancel", command=on_cancel, style="Dialog.TButton", width=8).pack(side=tk.RIGHT)
        
        dialog.bind('<Return>', lambda e: on_ok())
        dialog.bind('<Escape>', lambda e: on_cancel())
        
        dialog.wait_window(dialog)
        
        new_type = getattr(dialog, 'result', None)
        
        if not new_type:
            return
            
        if new_type in self.document_types:
            messagebox.showinfo("Duplicate", "This document type already exists", parent=self.root)
            return
            
        self.document_types.append(new_type)
        self.document_type_combobox['values'] = self.document_types
        self.document_type.set(new_type)
        
        try:
            with open(self.doc_types_csv, 'a', newline='', encoding='utf-8') as f:
                writer = csv.writer(f)
                writer.writerow([new_type])
            self.status_var.set(f"Added document type: {new_type}")
        except Exception as e:
            messagebox.showerror("Save Error", f"Failed to save to CSV:\n{str(e)}", parent=self.root)
    
    def cycle_document_type(self):
        """Cycle to next document type in list"""
        if not self.document_types:
            return
            
        current = self.document_type.get()
        
        try:
            current_index = self.document_types.index(current)
            next_index = (current_index + 1) % len(self.document_types)
        except ValueError:
            next_index = 0
            
        next_type = self.document_types[next_index]
        self.document_type.set(next_type)
        self.status_var.set(f"Document type: {next_type}")
        
    def previous_document_type(self):
        """Cycle to previous document type in list"""
        if not self.document_types:
            return
            
        current = self.document_type.get()
        
        try:
            current_index = self.document_types.index(current)
            prev_index = (current_index - 1) % len(self.document_types)
        except ValueError:
            prev_index = len(self.document_types) - 1
            
        prev_type = self.document_types[prev_index]
        self.document_type.set(prev_type)
        self.status_var.set(f"Document type: {prev_type}")
    
    def open_output_folder(self):
        """Open output folder in file explorer"""
        try:
            os.startfile(self.output_folder)
        except:
            try:
                import subprocess
                subprocess.Popen(['xdg-open', self.output_folder])
            except:
                self.status_var.set("Could not open output folder")

    def load_current_pdf(self):
        """Load current PDF file"""
        if self.current_pdf_index >= len(self.pdf_files):
            self.current_file_label.config(text="✅ All files processed!")
            if self.pdf_viewer:
                self.pdf_viewer.close_pdf()
            messagebox.showinfo("Complete", "All PDF files processed!", parent=self.root)
            return
        
        fname = self.pdf_files[self.current_pdf_index]
        self.current_file_label.config(text=f"[{self.current_pdf_index+1}/{len(self.pdf_files)}] {fname}")
        
        if self.pdf_viewer:
            pdf_path = os.path.join(self.pdf_folder, fname)
            self.pdf_viewer.load_pdf(pdf_path)
            
        self.status_var.set(f"Loaded: {fname}")

    def _perform_rename(self, account_display: str, doc_type: str, is_correction: bool = False) -> RenameOperation:
        """Perform file rename operation with optimizations"""
        current = self.pdf_files[self.current_pdf_index]
        src = os.path.join(self.pdf_folder, current)

        pn_number = self.account_display_to_pn.get(account_display)
        if not pn_number:
            raise PDFIndexerError(f"Account not found: {account_display}")

        account_name = account_display.split('_')[0]
        
        accounts_csv_name = os.path.splitext(os.path.basename(self.accounts_csv))[0]
        parent_folder = os.path.join(self.output_folder, accounts_csv_name)
        
        folder_name = f"{pn_number}_{account_name}"
        dest_folder = os.path.join(parent_folder, folder_name)
        os.makedirs(dest_folder, exist_ok=True)
        
        base = f"{pn_number}_{account_name}_{doc_type}"
        base = OptimizedFileManager.validate_filename(base)
        fname = f"{base}.pdf"
        dest = os.path.join(dest_folder, fname)
        
        # Handle duplicates
        counter = 1
        while os.path.exists(dest):
            fname = f"{base}_{counter}.pdf"
            dest = os.path.join(dest_folder, fname)
            counter += 1
        
        if is_correction and self.operation_to_correct:
            try:
                if os.path.exists(self.operation_to_correct.destination_path):
                    OptimizedFileManager.safe_delete_file(self.operation_to_correct.destination_path)
                    logger.info(f"Deleted previous version: {self.operation_to_correct.destination_path}")
                if self.operation_to_correct in self.rename_history:
                    self.rename_history.remove(self.operation_to_correct)
            except Exception as e:
                logger.error(f"Error deleting previous version: {str(e)}")
                raise PDFIndexerError(f"Failed to delete previous version: {str(e)}")
        
        OptimizedFileManager.safe_copy_file(src, dest)
        
        op = RenameOperation(
            original_index=self.current_pdf_index,
            original_filename=current,
            new_filename=fname,
            account_folder=dest_folder,
            timestamp=datetime.now(),
            source_path=src,
            destination_path=dest,
            account_display=account_display,
            document_type=doc_type
        )
        self.rename_history.append(op)
        self.status_var.set(f"Renamed: {fname}")
        
        return op

    def rename_and_next(self):
        """Rename current file and move to next"""
        acc = self.selected_account.get().strip()
        dt = self.document_type.get().strip()
        
        if not acc:
            messagebox.showerror("Error", "Please select an account", parent=self.root)
            return
        if not dt:
            messagebox.showerror("Error", "Please select a document type", parent=self.root)
            return
        
        is_correction = bool(self.operation_to_correct)
        
        try:
            start_time = time.time()
            op = self._perform_rename(acc, dt, is_correction)
            elapsed = time.time() - start_time
            logger.info(f"Rename operation completed in {elapsed:.2f}s")
        except PDFIndexerError as e:
            messagebox.showerror("Error", str(e), parent=self.root)
            return
        except Exception as e:
            logger.exception("Unexpected error during rename")
            messagebox.showerror("Error", f"Unexpected error: {str(e)}", parent=self.root)
            return
        
        if self.operation_to_correct:
            self.current_pdf_index = self.return_index
            self.return_index = None
            self.operation_to_correct = None
            self.status_var.set("Returned to original position")
        else:
            self.current_pdf_index += 1
        
        self.load_current_pdf()

    def go_back(self):
        """Undo last operation"""
        if not self.rename_history:
            messagebox.showinfo("Info", "Nothing to undo", parent=self.root)
            return
        
        op = self.rename_history.pop()
        try:
            if OptimizedFileManager.safe_delete_file(op.destination_path):
                self.status_var.set(f"Undone: {op.new_filename}")
            else:
                self.status_var.set("Delete failed - file may be in use")
        except Exception as e:
            logger.error(f"Error undoing operation: {str(e)}")
            messagebox.showerror("Error", f"Failed to undo: {str(e)}", parent=self.root)
            return
        
        self.current_pdf_index = op.original_index
        self.load_current_pdf()

    def skip_file(self):
        """Skip current file"""
        if messagebox.askyesno("Skip", "Skip without renaming this file?", parent=self.root):
            logger.info(f"Skipped file: {self.pdf_files[self.current_pdf_index]}")
            
            if self.operation_to_correct:
                self.current_pdf_index = self.return_index
                self.return_index = None
                self.operation_to_correct = None
                self.status_var.set("Skipped correction - returned to original position")
            else:
                self.current_pdf_index += 1
                self.status_var.set("Skipped")
                
            self.load_current_pdf()

    def next_account(self):
        """Move to next account in order"""
        if not self.account_combo:
            return
            
        current_account = self.selected_account.get()
        next_account = self.account_combo.get_next_in_original_order(current_account)
        
        if next_account:
            self.selected_account.set(next_account)
            
    def previous_account(self):
        """Move to previous account in order"""
        if not self.account_combo:
            return
            
        current_account = self.selected_account.get()
        prev_account = self.account_combo.get_previous_in_original_order(current_account)
        
        if prev_account:
            self.selected_account.set(prev_account)

    def create_account_combo_wrapper(self, accounts, combo_widget):
        """Create account combo wrapper"""
        class ComboWrapper:
            def __init__(self, accounts, combo):
                self.all_values = accounts
                self.original_order = {value: idx for idx, value in enumerate(accounts)}
                self.combo = combo
                
            def get_position_in_original_order(self, value):
                return self.original_order.get(value, -1)
                
            def get_next_in_original_order(self, current_value):
                if not current_value or current_value not in self.original_order:
                    return self.all_values[0] if self.all_values else ""
                current_pos = self.original_order[current_value]
                next_pos = (current_pos + 1) % len(self.all_values)
                return self.all_values[next_pos]
                
            def get_previous_in_original_order(self, current_value):
                if not current_value or current_value not in self.original_order:
                    return self.all_values[-1] if self.all_values else ""
                current_pos = self.original_order[current_value]
                prev_pos = (current_pos - 1) % len(self.all_values)
                return self.all_values[prev_pos]
                
            def get_position_info(self, value):
                if not value or value not in self.original_order:
                    return ""
                pos = self.original_order[value] + 1
                total = len(self.all_values)
                next_account = self.get_next_in_original_order(value)
                next_name = next_account.split('_')[0] if next_account else "None"
                return f"Position {pos}/{total} | Next: {next_name}"
                
        return ComboWrapper(accounts, combo_widget)

    def open_account_search(self):
        """Open optimized account search dialog"""
        try:
            accounts = list(self.account_display_to_pn.keys())
            current_selection = self.selected_account.get()
            
            dialog = OptimizedSearchDialog(self.root, accounts, current_selection)
            result = dialog.show()
            
            if result:
                self.selected_account.set(result)
                
        except Exception as e:
            messagebox.showerror("Search Error", f"Failed to open search: {str(e)}", parent=self.root)

    def update_title_and_position(self):
        """Update title and position info"""
        if not self.title_label:
            return
            
        acc = self.selected_account.get()
        if acc:
            account_name = acc.split('_')[0]
            self.title_label.config(text=account_name)
            
            if self.position_label and self.account_combo:
                position_info = self.account_combo.get_position_info(acc)
                self.position_label.config(text=position_info)
        else:
            self.title_label.config(text="Select an account to begin")
            if self.position_label:
                self.position_label.config(text="")

    def export_history(self):
        """Export rename history to Excel with formatting"""
        if not self.rename_history:
            messagebox.showinfo("Info", "No rename history to export", parent=self.root)
            return
        
        default_filename = f"rename_history_{datetime.now().strftime('%Y%m%d')}.xlsx"
        f = filedialog.asksaveasfilename(
            defaultextension='.xlsx',
            filetypes=[('Excel files', '*.xlsx'), ('All files', '*.*')],
            initialfile=default_filename,
            parent=self.root
        )
        
        if not f:
            return
        
        try:
            from openpyxl import Workbook
            from openpyxl.styles import Font, Border, Side, Alignment, PatternFill
            from openpyxl.utils import get_column_letter
            
            # Calculate summary statistics
            unique_accounts = set()
            
            for op in self.rename_history:
                account_name = op.account_display.split('_')[0]
                unique_accounts.add(account_name)
            
            # Prepare data
            data = []
            for op in self.rename_history:
                account_parts = op.account_display.split('_')
                account_name = account_parts[0]
                pn_number = account_parts[1] if len(account_parts) > 1 else ""
                
                date_str = op.timestamp.strftime('%m/%d/%Y')
                time_str = op.timestamp.strftime('%H:%M:%S')
                
                data.append({
                    'Date(MM/DD/YYYY)': date_str,
                    'Time (HH:MM:SS)': time_str,
                    'Original File Name': op.original_filename,
                    'New File name': op.new_filename,
                    'PN number': pn_number,
                    'Account Name': account_name,
                    'Document Type': op.document_type
                })
            
            # Create workbook
            wb = Workbook()
            ws = wb.active
            ws.title = "Rename History"
            
            # Define styles
            title_font = Font(bold=True, size=14, color="FFFFFF")
            normal_font = Font(size=10, color="000000")
            
            header_fill = PatternFill(start_color="304056", end_color="304056", fill_type="solid")
            no_border = Border()
            
            center_alignment = Alignment(horizontal='center', vertical='center')
            left_alignment = Alignment(horizontal='left', vertical='center')
            
            current_row = 1
            
            # Summary report title
            ws.cell(row=current_row, column=1, value="SUMMARY REPORT")
            ws.cell(row=current_row, column=1).font = title_font
            ws.cell(row=current_row, column=1).fill = header_fill
            ws.cell(row=current_row, column=1).alignment = center_alignment
            ws.merge_cells(start_row=current_row, start_column=1, end_row=current_row, end_column=7)
            current_row += 2
            
            # Summary information
            ws.cell(row=current_row, column=1, value="Total number of Renamed files:")
            ws.cell(row=current_row, column=1).font = normal_font
            ws.cell(row=current_row, column=1).alignment = left_alignment
            ws.cell(row=current_row, column=1).border = no_border
            
            ws.cell(row=current_row, column=2, value=len(self.rename_history))
            ws.cell(row=current_row, column=2).font = normal_font
            ws.cell(row=current_row, column=2).alignment = center_alignment
            ws.cell(row=current_row, column=2).border = no_border
            current_row += 1
            
            # Folder paths
            ws.cell(row=current_row, column=1, value="PDF Folder:")
            ws.cell(row=current_row, column=1).font = normal_font
            ws.cell(row=current_row, column=1).alignment = left_alignment
            ws.cell(row=current_row, column=1).border = no_border
            
            ws.cell(row=current_row, column=2, value=self.pdf_folder)
            ws.cell(row=current_row, column=2).font = normal_font
            ws.cell(row=current_row, column=2).alignment = left_alignment
            ws.cell(row=current_row, column=2).border = no_border
            current_row += 1
            
            ws.cell(row=current_row, column=1, value="Output Folder:")
            ws.cell(row=current_row, column=1).font = normal_font
            ws.cell(row=current_row, column=1).alignment = left_alignment
            ws.cell(row=current_row, column=1).border = no_border
            
            ws.cell(row=current_row, column=2, value=self.output_folder)
            ws.cell(row=current_row, column=2).font = normal_font
            ws.cell(row=current_row, column=2).alignment = left_alignment
            ws.cell(row=current_row, column=2).border = no_border
            current_row += 2
            
            # Data table headers
            if data:
                headers = list(data[0].keys())
                for col, header in enumerate(headers, 1):
                    cell = ws.cell(row=current_row, column=col, value=header)
                    cell.font = Font(bold=True, size=10, color="FFFFFF")
                    cell.fill = header_fill
                    cell.border = Border(
                        left=Side(style='thin'),
                        right=Side(style='thin'),
                        top=Side(style='thin'),
                        bottom=Side(style='thin')
                    )
                    cell.alignment = center_alignment
                current_row += 1
                
                # Data rows
                for row_data in data:
                    for col, header in enumerate(headers, 1):
                        cell = ws.cell(row=current_row, column=col, value=row_data[header])
                        cell.font = normal_font
                        cell.border = Border(
                            left=Side(style='thin'),
                            right=Side(style='thin'),
                            top=Side(style='thin'),
                            bottom=Side(style='thin')
                        )
                        cell.alignment = left_alignment
                    current_row += 1
            
            # Auto-adjust column widths
            for col_idx in range(1, 8):
                col_letter = get_column_letter(col_idx)
                if col_idx == 2:  # Time column
                    ws.column_dimensions[col_letter].width = 12
                    continue
                    
                max_length = 0
                for row in ws.iter_rows(min_col=col_idx, max_col=col_idx):
                    cell = row[0]
                    if cell.value:
                        value = str(cell.value)
                        if len(value) > max_length:
                            max_length = len(value)
                
                adjusted_width = min((max_length + 2) * 1.2, 255)
                ws.column_dimensions[col_letter].width = adjusted_width
            
            wb.save(f)
            
            messagebox.showinfo("Exported", f"History saved to:\n{f}", parent=self.root)
            self.status_var.set(f"Exported history to {os.path.basename(f)}")
            
        except ImportError:
            messagebox.showerror("Missing Library", 
                               "Excel export requires 'openpyxl' library.\n"
                               "Install it with: pip install openpyxl\n\n"
                               "Falling back to CSV export...", parent=self.root)
            
            # Fallback to CSV export
            self._export_history_csv(f.replace('.xlsx', '.csv'))
            
        except Exception as e:
            logger.error(f"Export error: {str(e)}")
            messagebox.showerror("Export Error", f"Failed to export: {str(e)}", parent=self.root)

    def _export_history_csv(self, filepath):
        """Export history to CSV format"""
        try:
            # Calculate summary statistics
            unique_accounts = set()
            document_type_counts = {}
            
            for op in self.rename_history:
                account_name = op.account_display.split('_')[0]
                unique_accounts.add(account_name)
                doc_type = op.document_type
                document_type_counts[doc_type] = document_type_counts.get(doc_type, 0) + 1
            
            # Prepare data
            data = []
            for op in self.rename_history:
                account_parts = op.account_display.split('_')
                account_name = account_parts[0]
                pn_number = account_parts[1] if len(account_parts) > 1 else ""
                
                data.append({
                    'Date': op.timestamp.strftime('%m/%d/%Y'),
                    'Time': op.timestamp.strftime('%H:%M:%S'),
                    'Original File Name': op.original_filename,
                    'New File name': op.new_filename,
                    'PN number': pn_number,
                    'Account Name': account_name,
                    'Document Type': op.document_type,
                    'Destination Path': op.destination_path,
                    'Source Path': op.source_path
                })
            
            with open(filepath, 'w', newline='', encoding='utf-8') as csvfile:
                writer = csv.writer(csvfile)
                
                writer.writerow(['SUMMARY REPORT'])
                writer.writerow([''])
                writer.writerow([f'Total number of Renamed files = {len(self.rename_history)}'])
                
                for doc_type, count in sorted(document_type_counts.items()):
                    writer.writerow([f'{doc_type} = {count}'])
                
                writer.writerow([''])
                writer.writerow([''])
                
                if data:
                    fieldnames = list(data[0].keys())
                    writer.writerow(fieldnames)
                    for row in data:
                        writer.writerow([row[field] for field in fieldnames])
            
            messagebox.showinfo("CSV Export", f"Exported as CSV instead:\n{filepath}", parent=self.root)
            
        except Exception as csv_error:
            logger.error(f"CSV fallback failed: {str(csv_error)}")
            messagebox.showerror("Export Error", f"Both Excel and CSV export failed:\n{str(csv_error)}", parent=self.root)

    def open_history_window(self):
        """Open history window for file navigation"""
        if not self.rename_history:
            messagebox.showinfo("Info", "No rename history available", parent=self.root)
            return
        
        win = tk.Toplevel(self.root)
        win.title('Jump to File')
        win.geometry("670x425")
        win.transient(self.root)
        win.grab_set()
        win.configure(bg="#304056")
        self.set_window_icon(win)
        
        # Configure styles
        style = ttk.Style(win)
        style.configure("Treeview", background="#405c7c", foreground="#ffffff", 
                       fieldbackground="#304056", rowheight=20)
        style.configure("Treeview.Heading", background="#1D421E", foreground="#ffffff", 
                       font=("Segoe UI", 9, 'bold'))
        style.map("Treeview", background=[('selected', '#FEC80B')], 
                 foreground=[('selected', '#000000')])
        style.configure("Preview.TLabel", background="#203040", foreground="#cccccc", 
                       font=("Segoe UI", 8), anchor=tk.W, padding=(5, 2))
        
        main_frame = ttk.Frame(win, padding=10)
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Title
        title_frame = ttk.Frame(main_frame)
        title_frame.pack(fill=tk.X, pady=(0, 8))
        
        ttk.Label(title_frame, text=f"History ({len(self.rename_history)} items)", 
                 font=("Segoe UI", 10, 'bold'), foreground="#FEC80B", 
                 background="#304056").pack(anchor=tk.W)
        
        # Tree view
        tree_frame = ttk.Frame(main_frame)
        tree_frame.pack(fill=tk.BOTH, expand=True)
        
        scrollbar = ttk.Scrollbar(tree_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        cols = ['#', 'Original', 'New']
        tree = ttk.Treeview(tree_frame, columns=cols, show='headings', height=10, 
                           yscrollcommand=scrollbar.set, selectmode='browse')
        scrollbar.config(command=tree.yview)
        
        tree.column('#', width=60, anchor=tk.CENTER, stretch=False)
        tree.column('Original', width=200, anchor=tk.W, stretch=False)
        tree.column('New', width=380, anchor=tk.W, stretch=False)
        
        tree.heading('#', text='#')
        tree.heading('Original', text='Original File')
        tree.heading('New', text='New File')
        
        # Populate tree
        for op in self.rename_history:
            tree.insert('', 'end', values=(
                op.original_index + 1,
                op.original_filename[:35] + "..." if len(op.original_filename) > 35 else op.original_filename,
                op.new_filename[:55] + "..." if len(op.new_filename) > 55 else op.new_filename
            ), tags=(op.original_index,))
        
        tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        # Preview frame
        preview_frame = ttk.Frame(main_frame, style="Preview.TFrame")
        preview_frame.pack(fill=tk.X, pady=(8, 5))
        
        preview_label = ttk.Label(preview_frame, text="Preview: Select an item to view details", 
                                style="Preview.TLabel")
        preview_label.pack(fill=tk.X, padx=2, pady=2)
        
        def update_preview(event=None):
            """Update preview based on selection"""
            sel = tree.selection()
            if not sel:
                preview_label.config(text="Preview: Select an item to view details")
                return
            
            item = tree.item(sel[0])
            orig_index = item['tags'][0]
            
            for op in self.rename_history:
                if op.original_index == orig_index:
                    preview_text = (
                        f"Original: {op.original_filename}\n"
                        f"Renamed: {op.new_filename}\n"
                        f"Account: {op.account_display.split('_')[0]}\n"
                        f"Document Type: {op.document_type}"
                    )
                    preview_label.config(text=preview_text)
                    return
        
        tree.bind('<<TreeviewSelect>>', update_preview)
        
        # Buttons
        btn_frame = ttk.Frame(main_frame)
        btn_frame.pack(fill=tk.X, pady=(5, 0))
        
        def select():
            """Select item for correction"""
            sel = tree.selection()
            if not sel:
                return
                
            item = tree.item(sel[0])
            orig_index = item['tags'][0]
            
            for op in self.rename_history:
                if op.original_index == orig_index:
                    self.operation_to_correct = op
                    break
            
            if self.operation_to_correct:
                self.return_index = self.current_pdf_index
                self.current_pdf_index = orig_index
                self.selected_account.set(self.operation_to_correct.account_display)
                self.document_type.set(self.operation_to_correct.document_type)
                self.load_current_pdf()
                self.status_var.set(f"Correcting: {self.operation_to_correct.new_filename}")
                win.destroy()
        
        btn_container = ttk.Frame(btn_frame)
        btn_container.pack(expand=True, pady=(5, 0))
        
        ttk.Button(btn_container, text='Cancel', command=win.destroy, width=12, 
                  style="Secondary.TButton").pack(side=tk.LEFT, padx=10)
        ttk.Button(btn_container, text='Select', command=select, width=12, 
                  style="TButton").pack(side=tk.LEFT, padx=10)
        
        # Initialize preview
        update_preview()
        
        if tree.get_children():
            tree.selection_set(tree.get_children()[0])
            tree.focus_set()
        
        # Position window
        self.root.update_idletasks()
        main_x = self.root.winfo_x()
        main_y = self.root.winfo_y()
        main_width = self.root.winfo_width()
        win.geometry(f"+{main_x + main_width//2 - 360}+{main_y + 50}")

    def on_closing(self):
        """Handle application closing with cleanup"""
        if messagebox.askokcancel("Quit", "Are you sure you want to quit?", parent=self.root):
            if self.pdf_viewer:
                self.pdf_viewer.close_pdf()
            # Clear caches
            OptimizedCSVManager.load_and_validate_csv.cache_clear()
            OptimizedFileManager._cached_file_hash.cache_clear()
            self.root.destroy()

    def run(self):
        """Run the application"""
        try:
            if self.initialize_application():
                self.create_gui()
                self.root.mainloop()
        except Exception as e:
            logger.exception("Critical error during initialization")
            messagebox.showerror("Fatal Error", f"Application failed to start:\n{str(e)}")
            if self.root:
                self.root.destroy()

def main():
    """Main entry point"""
    # Check dependencies
    try:
        import fitz
        from PIL import Image, ImageTk
    except ImportError as e:
        print(f"Missing required dependency: {e}")
        print("\nTo install required packages, run:")
        print("pip install PyMuPDF Pillow")
        input("Press Enter to exit...")
        sys.exit(1)
    
    # Run application
    app = PDFIndexer()
    app.run()

if __name__ == '__main__':
    main()